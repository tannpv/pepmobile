<?php
// no direct access
defined('_JEXEC') or die('Restricted access');
//var_dump($lists);
?>
<!--<div id="myCarousel" class="carousel slide">
     Dot Indicators 
    <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
        <li data-target="#myCarousel" data-slide-to="3"></li>
        <li data-target="#myCarousel" data-slide-to="4"></li>
        <li data-target="#myCarousel" data-slide-to="5"></li>
        <li data-target="#myCarousel" data-slide-to="6"></li>

    </ol>
    <div class="carousel-inner">

        <div class="item active">
            <img src="banner/img01.jpg" alt="slider image">
        </div>
        <div class="item">
            <img src="images/slider/img02.jpg" alt="slider image">
        </div>
        <div class="item">
            <img src="images/slider/img03.jpg" alt="slider image">
        </div>
        <div class="item">
            <img src="images/slider/img04.jpg" alt="slider image">
        </div>
        <div class="item">
            <img src="images/slider/img05.jpg" alt="slider image">
        </div>
        <div class="item">
            <img src="images/slider/img06.jpg" alt="slider image">
        </div>
        <div class="item">
            <img src="images/slider/img07.jpg" alt="slider image">
        </div>

    </div>
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">&lsaquo;</a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">&rsaquo;</a> 
    <div class="carousel-shadow"></div>
</div>   /.carousel -->

<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td align="center" width="100%"><img src="http://localhost/pepmobile/images/titles/members.gif" border="0" alt="Membership Listing" />
<table border="1">
<tbody>
<tr>
<td bgcolor="#C0C0C0"><span style="font-size: small;"><strong>Company Name</strong></span></td>
<td bgcolor="#C0C0C0"><span style="font-size: small;"><strong>Representative</strong></span></td>
</tr>
<?php foreach $lists as $row : ?>
<tr>
<td><span style="font-size: small;"><?php echo $row->company ?></span></td>
<td><span style="font-size: small;"><a href="#" target="_blank"><?php echo $row->website ?></a></span> </td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</td>
</tr>
<tr>
<td align="center" width="100%"><span style="font-family: Tahoma,Verdana,Arial; font-size: small;"> </span></td>
</tr>
<tr>
<td width="100%"><span style="font-family: Tahoma,Verdana,Arial; font-size: small;">If you are a member of PEP and would like to have your company information listed on the PEP Website, please <a href="http://localhost/pepmobile/contact/contact.asp">contact us</a> for more information.</span></td>
</tr>
</tbody>
</table>