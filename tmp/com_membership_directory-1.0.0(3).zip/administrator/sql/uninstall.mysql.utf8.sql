DROP TABLE IF EXISTS `#__membership_directory`;
