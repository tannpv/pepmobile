<?php
/**
 * @version     1.0.0
 * @package     com_membership_directory
 * @copyright   Copyright (C) 2013. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Joomla Component <Joomla@Joomla.com> - http://www.joomla.org
 */

defined('_JEXEC') or die;

abstract class Membership_directoryHelper
{
	public static function myFunction()
	{
		$result = 'Something';
		return $result;
	}

}

