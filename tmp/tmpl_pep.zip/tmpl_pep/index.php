<!DOCTYPE html>
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en" class="no-js"> <!--<![endif]-->
<head>
 	<meta charset="utf-8">
	<meta name="description" content="" />
	<meta name="author" content="">
	<meta name="keywords" content="" />
	<!-- Optimized mobile viewport -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- HTML5 IE Enabling Script -->
	<!--[if lt IE 9]><script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
  <title>PEP - Partners for Environmental Progress</title>
	<!-- Place favicon.ico and apple-touch-icon.png in root directory -->
  	<link rel="shortcut icon" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template; ?>/favicon.ico">
 	<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template; ?>/css/style.css">
	<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template; ?>/css/nanoscroller.css">
<link href='http://fonts.googleapis.com/css?family=Archivo+Narrow:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template; ?>/images/nivo-slider/themes/default/default.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template; ?>/css/nivo-slider.css" type="text/css" media="screen" />


</head>


<body class="home-page">
<div class="wrap">
<header>
<div class="logo-block">
<div class="login"><a href="#">Login</a></login>
</div>
</header>
<nav>
  <ul class="main-menu">
<li><a class="sub-menu" href="about-us.html">About Us</a>
<ul class="topnav-dropdown">
<li><a href="mission.html">Mission</a></li>
<li><a href="board-of-directors.html">Board of Directors</a></li>
<li><a href="staff.html">Staff</a></li>
<li><a href="standee-committees.html">Standee Committees</a></li>
</ul>
</li>
<li><a class="sub-menu" href="BPS.html">BPS</a>
<ul class="topnav-dropdown">
<li><a href="about-BPS.html">About BPS</a></li>
<li><a href="BPS-awards.html">BPS Awards</a></li>
<li><a href="member-login.html">Member Login</a></li>
</ul>

</li>
<li><a class="sub-menu" href="awards.html">Awards and Recognition</a>
<ul class="topnav-dropdown">
<li><a class="member-environment-award.html">Member & Environmental Award</a></li>
<li><a href="BPS-awards.html">BPS Awards</a></li>
</ul>

</li>
<li><a  href="new-issues.html">News and Issues</a></li>
<li><a href="events.html">Events</a></li>
<li><a class="sub-menu" href="members.html">PEP members</a>
<ul class="topnav-dropdown">
<li><a class="alpha-order.html">In Alpha Order</a></li>
<li><a href="catergory-sort.html">Members by Categories</a></li>
<li><a href="members-in-news.html">Members in the News</a></li>
<li><a href="member-environment-award.html">Member & Environmental Awards</a></li>
<li><a href="member-login.html">Member Login</a></li>
</ul>


</li>
<li><a href="join.html">Join PEP</a></li>
<li><a href="contact.html">Contact Us</a></li>
<li><a href="links.html">Links</a></li>
</ul>
</nav>
<div class="col-group main-page">
<div class="span1 col cf">
<div id="event-box" class="nano">
<div  class="content">
<dl >
<dt><h3>UPCOMING EVENTS</h3></dt>
<dd><h4>Membership Breakfast</h4>
<p><strong>February Speaker:</strong><br/>
To Come<br/>
<strong>Sponsor:</strong><br/>
To Come<br/></p></dd>
<dd><h4>13th Annual<br/>Golf Invitational</h4>
<p>February Speaker:<br/>
To Come<br/>
Sponsor:<br/>
To Come<br/></p></dd>

</dl>

</div>

</div>
<!--facebook panel -->
<div class="facebook-widget">
<div class=" nano">
<div class="content">
<h3>Facebook</h3>
</div>
</div>
</div>
<!--//facebook panel -->
</div>
<!--end left column-->
<div class="span3 col right-panel">
<div class="top-para-block"><div class="left-small-block"><p>Partners for</p>
<p>Environmental</p>
<p>Progress</p></div>
<p class="right-para-block">PEP) is a coalition of business and education leaders who share the vision of applying science-based environmental best practices in business and our community. PEP was founded in the year 2000 on the guiding principle of promoting business growth while preserving the environment and overall quality of life along the Gulf Coast.</p></div>

<div class="col-group second-para-block">
<div class="span4 current-event-block">
<h3>2013 Industrial<br>Reverse Tradeshow</h3>
<p>Thursday, October 17 at Ft. Whiting, Brookley Aeroplex. <a href="#">Read more & purchase tickets</a>…</p>
<p></p>
</div>
<div class="span5">
    <div class="slider-wrapper theme-default">
        <div id="slider" class="nivoSlider">
            <img src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template; ?>/images/slideshow/slider01.jpg" alt="alternating text slider 01" />
            <img src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template; ?>/images/slideshow/slider02.jpg" alt="alternating text slider 01" />
   </div>
</div>
</div>
</div>
</div>
<!--end right column-->

</div>

<footer>

<dl>
<dd class="fb"><a href="">LIKE us on facebook!</a></dd>
<dd class="lin"><a href="http://www.linkedin.com/company/partners-for-environmental-progress"></a></dd>
<dd>754 Downtowner Loop West, Mobile, Alabama 36609</dd>
<dd>251.345.7269</dd>
<dd>director@pepmobile.org </dd>
</dl>


</footer>
</div>
<!--end wrap -->
<!-- JavaScript at the bottom for fast page loading -->

 <!--Text box scroll -->
 <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
 <script src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template; ?>/js/jquery.nanoscroller.min.js">  </script>
<script type="text/javascript">
  $(window).load(function() {
        $(".nano").nanoScroller({ scroll: 'top' });
    });
    </script>
<!--Nivo Slider -->
<script type="text/javascript" src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template; ?>/js/jquery.nivo.slider.js"></script>
</script>
<script type="text/javascript">
    $(window).load(function() {
         $('#slider').nivoSlider({
        controlNav: true, // 1,2,3... navigation
		pauseTime: 3000, // How long each slide will show
		effect: 'fade', // Specify sets like: 'fold,fade,sliceDown'
    });
    });
    </script>
<!-- Minimized jQuery from Google CDN -->

<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.5.3/modernizr.min.js"></script>
	
<!-- Optimized Google Analytics. Change UA-XXXXX-X to your site ID -->
<script>var _gaq=[['_setAccount','UA-XXXXX-X'],['_trackPageview']];(function(d,t){var g=d.createElement(t),s=d.getElementsByTagName(t)[0];g.src='//www.google-analytics.com/ga.js';s.parentNode.insertBefore(g,s)}(document,'script'))</script>
</body>
</html>