<?php
// no direct access
defined('_JEXEC') or die('Restricted access');
//var_dump($lists);
?>
<div id="myCarousel" class="carousel slide">
    <!-- Dot Indicators -->
    <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
        <li data-target="#myCarousel" data-slide-to="3"></li>
        <li data-target="#myCarousel" data-slide-to="4"></li>
        <li data-target="#myCarousel" data-slide-to="5"></li>
        <li data-target="#myCarousel" data-slide-to="6"></li>

    </ol>
    <div class="carousel-inner">
      <?php $i=0; 
      foreach ($lists as $slider) :
        //  var_dump($slider->filename);
          if($i==0)
          {
      ?>
        <div class="item active"><img src="" />
             <img src="<?php echo JURI::base(); ?>/images/phocagallery/<?php echo $slider->filename ?>" alt="slider image" />
        </div>
        <?}else{?>
        <div class="item">
           <img src="<?php echo JURI::base(); ?>/images/phocagallery/<?php echo $slider->filename ?>" alt="slider image" />
        </div>
        
      <?php }
      $i++;
      endforeach;?>
    </div>
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">&lsaquo;</a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">&rsaquo;</a> 
    <div class="carousel-shadow"></div>
</div>  