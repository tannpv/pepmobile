<?php 
defined('_JEXEC') or die('Restricted access');

include(JEV_VIEWS."/default/range/tmpl/".basename(__FILE__));
