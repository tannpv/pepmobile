
<?php 
defined('_JEXEC') or die('Restricted access'); ?>

<?php  echo $item->introtext; ?>
<a href="#">Contribute</a>