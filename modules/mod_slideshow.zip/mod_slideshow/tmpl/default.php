
<?php defined('_JEXEC') or die('Restricted access');

 
?>
<div class="slideshowFrame"> 
    <div class="slideshow">
        <div id="nav" ></div>
        <?php foreach ($items as $item ) { ?>
        <a class="clearfix" href="#">
            <span class="caption"><?php echo $item->description ?></span>
            <img src="<?php echo JURI::base(); ?>images/phocagallery/<?php echo $item->filename ?>" width="670" height="378" />
        </a>
        <?php } ?>
    </div>
</div> 