<?php
    class modSlideshow
    {
        function getImgSlideshow() 
        {                   
            $db=& JFactory::getDBO();
            $query="select * from jos_phocagallery ";
            $db->setQuery($query);
            $list=$db->loadObjectList();
            return $list;
        }
    }

?>