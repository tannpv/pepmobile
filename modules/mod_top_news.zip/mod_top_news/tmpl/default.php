
<?php defined('_JEXEC') or die('Restricted access'); ?>
<h3>TOP NEWS</H3>
<h4 style="font-weight: bold"><?php echo $item->title ?></h4>

<span class="postedDate"><?php echo JHtml::_('date', $item->created, "F j, Y"); ?></span>
<p style="font-size: 10px;"><?php echo $item->introtext ?><a href="<?php echo JURI::base(); ?>index.php/component/content/article?id=<?php echo $item->id ?>">»</a></p>
<a style="font-size: 10px;" href="index.php?option=com_content&view=category&id=90">View All News »</a>

