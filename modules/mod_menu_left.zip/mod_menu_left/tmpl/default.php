
<?php defined('_JEXEC') or die('Restricted access'); ?>

<ul class="actionMenu">
<h3>TAKE ACTION</h3>
<li><a href="#">Report Pollution</a></li>
<li><a href="#">Subscribe to Bay Waves</a></li>
<li><a href="#">Sign up for Baykeeper 101</a></li>
<li><a href="#">Become a Fan on Facebook</a></li>
<li><a href="#">Follow us in Twitter</a></li>
<li><a href="#">Subscribe to the RSS feed</a></li>
<li class="WA"><a href="#">Waterkeeper Alliance Member©</a></li>
<li class="copyright">© Copyright Mobile Baykeeper 2012. All rights reserved.</li>
</ul>