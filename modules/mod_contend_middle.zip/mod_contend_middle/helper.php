<?php

require_once JPATH_SITE . '/components/com_content/helpers/route.php';

jimport('joomla.application.component.model');

JModel::addIncludePath(JPATH_SITE . '/components/com_content/models', 'ContentModel');

class modContend_Middle {

//    function getCategories() {
//
//        $model = JModel::getInstance('Categories', 'ContentModel', array('ignore_request' => true));
//        
//        $app = JFactory::getApplication();//vucao
//        $appParams = $app->getParams();///vucao
//        $model->setState('params', $appParams);//vucao
//        $model->setState('id', array(85, 86));
//        $items = $model->getItems();
//
//          return $items;
//       
//    }

}

?>