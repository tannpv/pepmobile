<?php
 //   defined('_JEXEC') or die('Restricted access.');
  //  require_once (dirname(__FILE__).DS.'helper.php');
   // $items=  modContend_Middle::getCategories();
//    //$item2=  modTakeActionLeft::getArticle2($a);
    require JModuleHelper::getLayoutPath('mod_contend_middle');
?>