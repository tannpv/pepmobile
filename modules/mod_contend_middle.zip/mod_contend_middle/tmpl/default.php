
<?php defined('_JEXEC') or die('Restricted access'); ?>

<?php
//echo $item->introtext; 
// var_dump($items);

?>
 <div class="boxLayout">
<ul>
    <li><a href="index.php?option=com_content&view=article&id=89">
            <h3>Donate</h3>
            <img src="/mobilebaykeeper/templates/mobilebaykeeper1/images/banner/donate.png" width="173" height="109" /></a></li>
    <li><a href="index.php?option=com_content&view=category&id=86">
            <h3>Get Involved</h3>
            <img src="/mobilebaykeeper/templates/mobilebaykeeper1/images/banner/get involed.png" width="173" height="109" /></a></li>
    <li><a href="/mobilebaykeeper/mobilebaykeeperblog/MobilebayBlog">
            <h3>Blog</h3>
            <img src="/mobilebaykeeper/templates/mobilebaykeeper1/images/banner/blog.jpg" width="173" height="109" /></a></li>
    <li><a href="index.php?option=com_content&view=category&id=88">
            <h3>Media</h3>
            <img src="/mobilebaykeeper/templates/mobilebaykeeper1/images/banner/thumb.png" width="173" height="109" /></a></li>
</ul>
     </div>